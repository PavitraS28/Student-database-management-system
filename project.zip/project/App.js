var express = require('express')
var app=express();
var bodyParser=require('body-parser');
var port=2818;

app.use(bodyParser.urlencoded({extended:false}));
app.use(express.static(__dirname));

app.use('/Student_Signup',function(req,res){
    console.log('Welcome!! To ExpressJS');
    res.sendFile(__dirname+'/views/Student_Signup.html');
})

app.post('/validatesignup', function(req,res){
    var name = req.body.n1;
    var rno = req.body.r1;
    var email = req.body.e1;
    var pword = req.body.p1;
    var cword = req.body.p2;
    var gen = req.body.gen;
    res.writeHead(200,{'Content-type':'text/html'});
    res.write("<h2>YOUR REGISTRATION COMPLETED SUCCESSFULLY!!-:) </h2>");
    res.end();
})

app.use('/Student_Login',function(req,res){
    console.log('WELCOME!!');
    res.sendFile(__dirname+'/views/Student_Login.html');
})


app.post('/validatelogin',function(req,res){
    var email = req.body.e1;
    var pword = req.body.p1;
    // res.writeHead(200,{'Content-type':'text/html'});
    res.send(`NAME ENTERED IN LOGINPAGE : ${email}, PASSWORD ENTERED IN LOGINPAGE:${pword}`);
    // res.write("<h2>CONGRATS!! YOU HAVE SUCCESSFULLY LOGGED IN :)</h2>");
    // res.end();
})

app.get('/Student_Signup');
app.get('/Student_Login');

app.listen(port,()=>{
    console.log(`Our Server is running at port ${port}`);
})