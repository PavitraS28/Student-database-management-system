function create_account()
    {    
        var e=document.getElementById("e1").value;
        var p=document.getElementById("p1").value;
            var email_val = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;  
        
        if(e==''||p=='')
        {  
            alert("Dont leave blank space"); 
         
        }  
        else if(!email_val.test(e))  
        {  
            alert('Invalid email format');
        }
        else{
            alert('Welcome');
        }
    }